		<!-- SharpSpring -->
		<script type="text/javascript">
	    var __ss_noform = __ss_noform || [];
	    __ss_noform.push(['baseURI', 'https://app-UUHGVW.marketingautomation.services/webforms/receivePostback/MzQ1sAAA/']);
	    __ss_noform.push(['form','contact-form', ss_form_id]);
	    __ss_noform.push(['submitType', 'manual']);
		</script>
		<script type="text/javascript" src="https://koi-UUHGVW.marketingautomation.services/client/noform.js?ver=1.24" ></script>
		<!-- End SharpSpring -->

	  <?php wp_footer(); ?>

	  <script src="<?php bloginfo('template_directory'); ?>/dist/assets/js/owl.carousel.min.js" defer></script>
	</body>
</html>